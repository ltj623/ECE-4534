#include "pixy_thread.h"
    

void PIXY_THREAD_Initialize ( void )
{
   
    initPorts();
    createQueue(); 
    create100msTimer();
    start100msTimer();
    currState = STATE_TX;
    
}

void PIXY_THREAD_Tasks ( void )
{
    currState = uart_FSM(currState);
    //"GET /Arm_State HTTP/1.1\r\nHost: 192.168.20.57\r\n\r\n"
}

/*******************************************************************************
 End of File
 */
