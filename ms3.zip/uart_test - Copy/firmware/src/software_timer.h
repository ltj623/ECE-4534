#ifndef _TIMERS_H    /* Guard against multiple inclusion */
#define _TIMERS_H

#include "FreeRTOS.h"
#include "timers.h"
#include "debug.h"

/* Provide C++ Compatibility */
#ifdef __cplusplus
extern "C" {
#endif

TimerHandle_t timerHndl100ms;
BaseType_t isTimerActive();
void sendToUART(TimerHandle_t xTimer);
void create100msTimer();
void start100msTimer();
void stop100msTimer();
void reset100msTimer();
 
    /* Provide C++ Compatibility */
#ifdef __cplusplus
}
#endif

#endif /* _EXAMPLE_FILE_NAME_H */

/* *****************************************************************************
 End of File
 */
