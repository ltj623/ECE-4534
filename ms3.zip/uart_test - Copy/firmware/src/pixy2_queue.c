#include "pixy2_queue.h"


void createPixyQueue() {
     UART1Queue = xQueueCreate(25, sizeof(char));
     PixyThreadQueue = xQueueCreate(25, sizeof(char));
}

BaseType_t sendPixyThreadQueueISR(char data) {
    //dbgOutputLoc(B4_SEND_PIXY_QUEUE_ISR);
    BaseType_t xTaskWokenByReceive = pdFALSE;
    if(PixyThreadQueue != (int) 0){
        xQueueSendToBackFromISR(PixyThreadQueue, &data, &xTaskWokenByReceive);
    }   
   //dbgOutputLoc(AFTER_SEND_PIXY_QUEUE_ISR);
    return pdTRUE;
}

BaseType_t sendPixyThreadQueue(char msg) {
   // dbgOutputLoc(B4_SEND_PIXY_QUEUE);
    if(PixyThreadQueue != (int) 0){
        xQueueSendToBack( PixyThreadQueue , (void *) &msg , (TickType_t) 5 );
    }
   //dbgOutputLoc(AFTER_SEND_PIXY_QUEUE);
    return pdTRUE;
}

BaseType_t sendUART1Queue(char msg) {
   // dbgOutputLoc(B4_SEND_UART1QUEUE);
    if(UART1Queue != (int) 0){
        xQueueSendToBack( UART1Queue , (void *) &msg , (TickType_t) 50 );
    }
   //dbgOutputLoc(AFTER_SEND_UART1QUEUE);
    return pdTRUE;
}

char receivePixyThreadQueue() {
    //dbgOutputLoc(B4_RECEIVE_PIXY_QUEUE);
   char msgReceived;
   if(PixyThreadQueue != (int) 0){
   xQueueReceive( PixyThreadQueue, ( void * ) &msgReceived, (TickType_t)portMAX_DELAY);
   }
   //dbgOutputLoc(AFTER_RECEIVE_PIXY_QUEUE);
   return msgReceived;
}

void receiveUART1QueueISR(char * msg) {
   //dbgOutputLoc(B4_RECEIVE_UART1_QUEUE);
   char msgReceived;
   BaseType_t xTaskWokenByReceive = pdFALSE;
   if(UART1Queue != 0){
     xQueueReceiveFromISR( UART1Queue, ( void * ) &msgReceived, &xTaskWokenByReceive);
   }
   *msg = msgReceived;
 // dbgOutputLoc(AFTER_RECEIVE_UART1_QUEUE);
}

BaseType_t PixyThreadQueueEmpty(){

   if(xQueueIsQueueEmptyFromISR(PixyThreadQueue)){
       return pdTRUE;
   }
   else{
       return pdFALSE;
   }
}

BaseType_t UART1QueueEmpty(){

   if(xQueueIsQueueEmptyFromISR(UART1Queue) == (BaseType_t) pdTRUE){
       return pdTRUE;
   }
   else{
       return pdFALSE;
   }
}

UBaseType_t spaceInPixyThreadQueue(){
    return uxQueueSpacesAvailable(PixyThreadQueue);
}
