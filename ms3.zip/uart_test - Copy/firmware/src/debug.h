#ifndef DEBUG_H
#define	DEBUG_H

#include "pixy_thread.h"
#include <stdio.h>
#include <stdlib.h>


#define ENTER_TIMER         0x01
#define LEAVE_TIMER         0x02

#define ENTERING_TX         0x21
#define LEAVING_TX          0x22
#define ENTERING_RX         0x23
#define LEAVING_RX          0x24

#define B4_SEND_BYTE       0x31
#define AFTER_SEND_BYTE    0x32
#define B4_RECEIVE_BYTE_ISR    0x33
#define AFTER_RECEIVE_BYTE_ISR 0x34

#define ERROR               0x00

void dbgOutputLoc(unsigned int outVal);
void ERROR_CHECK(bool errorFree);

#endif	/* DEBUG_H */