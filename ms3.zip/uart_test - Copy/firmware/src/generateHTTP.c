#include "generatehttp.h"


void GENERATEHTTP_Initialize ( void )
{
    createQueue();
    createPixyQueue();
    create100msTimer();
    start100msTimer();
}

void GENERATEHTTP_Tasks ( void )
{
    char data = receivePixyThreadQueue();
    find_block(data);

}

 

/*******************************************************************************
 End of File
 */
