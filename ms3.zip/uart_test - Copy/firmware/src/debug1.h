#ifndef DEBUG1_H
#define	DEBUG1_H

#include "WiFly_thread.h"
#include "generateHTTP.h"
#include <stdio.h>
#include <stdlib.h>



void dbgOutputLoc(unsigned int outVal);
void dbgOutputBlockCC(unsigned int outVal);
void ERROR_CHECK(bool errorFree);


#endif	/* DEBUG_H */