#include "pixy_queue.h"
#include "system_definitions.h"

void createQueue() {
    timer_send_queue = xQueueCreate(6, sizeof(uint16_t));
    pixy_thread_queue = xQueueCreate(25, sizeof(uint16_t));
    //queue = xQueueCreate( 8, sizeof( struct AMessage * ) );
}

BaseType_t sendSensorValueToQueue(char message) {
    //dbgOutputLoc(B4_SENDING_ISR);
    BaseType_t xHigherPriorityTaskWoken;
    xHigherPriorityTaskWoken = pdFALSE;
    xQueueSendToBackFromISR( pixy_thread_queue, &message, &xHigherPriorityTaskWoken );  
   // dbgOutputLoc(AFTER_SENDING_ISR);
    return xHigherPriorityTaskWoken;
}

BaseType_t sendPixyValueToQueue(char message) {
    //dbgOutputLoc(B4_SENDING_ISR);

    xQueueSendToBack( timer_send_queue, &message, ( TickType_t )pdMS_TO_TICKS(100) );
    
   // dbgOutputLoc(AFTER_SENDING_ISR);
    return pdTRUE;
}

UBaseType_t spaceInQueue(){
    return uxQueueSpacesAvailable(timer_send_queue);
}
char readSensorValueFromQueue() {
    char value;
    //dbgOutputLoc(B4_RECIEVING_TASK);
    BaseType_t xTaskWokenByReceive = pdFALSE;
    if (pixy_thread_queue != 0) {
        xTaskWokenByReceive = xQueueReceive( pixy_thread_queue, &( value ), ( TickType_t ) portMAX_DELAY);
    }
   // dbgOutputLoc(AFTER_RECIEVING_TASK);
    return value;
}

BaseType_t readTimerValueFromQueue() {
    BaseType_t value;
    //dbgOutputLoc(B4_RECIEVING_TASK);
    BaseType_t xTaskWokenByReceive = pdFALSE;
    if (pixy_thread_queue != 0) {
       xQueueReceiveFromISR( timer_send_queue, &value, &xTaskWokenByReceive);
    }
   // dbgOutputLoc(AFTER_RECIEVING_TASK);
    return value;
}

void resetQueue(){
    xQueueReset(timer_send_queue);
}
