#ifndef _PIXY_QUEUE_H    /* Guard against multiple inclusion */
#define _PIXY_QUEUE_H

#include "FreeRTOS.h"
#include <queue.h>
#include "debug.h"
#ifdef __cplusplus
extern "C" {
#endif

QueueHandle_t timer_send_queue;
QueueHandle_t pixy_thread_queue;
void createQueue();
BaseType_t sendSensorValueToQueue(char message);
BaseType_t sendPixyValueToQueue(char message);
UBaseType_t spaceInQueue();
char readSensorValueFromQueue();
BaseType_t readTimerValueFromQueue();
void resetQueue();
    
#ifdef __cplusplus
}
#endif

#endif 


