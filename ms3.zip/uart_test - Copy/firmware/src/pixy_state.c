#include "pixy_state.h"

void find_block(char data){
    //dbgOutputLoc(ENTER_FIND_BLOCK);
    static uint16_t pixy_data[50];
    static int16_t count = 0;
    static BaseType_t red_found = pdFALSE;
    static BaseType_t green_found = pdFALSE;
    static BaseType_t none_found = pdFALSE;
    
    if(count <= 20){
        pixy_data[count] = data;

        if(count > 0){
            if((pixy_data[count-1] == (uint16_t)0x01) && (pixy_data[count] == (uint16_t)0x00)){
                red_found = pdTRUE;
                green_found = pdFALSE;
                none_found = pdFALSE;
                count = 21;
            }
            else if((pixy_data[count-1] == (uint16_t)0x02) && (pixy_data[count] == (uint16_t)0x00)){
                green_found = pdTRUE;
                red_found = pdFALSE;
                none_found = pdFALSE;
                count = 21;
            }
            else if((pixy_data[count-1] == (uint16_t)0x21) && (pixy_data[count] == (uint16_t)0x00)){
                green_found = pdFALSE;
                red_found = pdFALSE;
                none_found = pdTRUE;
                count = 21;
            }

        }
        count = count + 1;
    }
    else{
       count = 0;
       memset(pixy_data, 0, 25);
       static struct WiFlyMsg msg;
       
        char buff[500];
        char body[500];
        int sent_msg_size = 0;
        static int count = 0;
        static int seqNum = 1;
        static PIXY_STATE state;
       
        switch(state){
            case START:{
                if(red_found){
                    state = FOUND_RED;
                }
                else if(green_found){
                    state = FOUND_GREEN;
                }
                else if(none_found){
                    state = FOUND_NONE;
                }
                break;
            }
            case FOUND_RED:{
                sprintf(body, "{\"color\": \"red\", \"xcor\": 3, \"ycor\": 5, \"seqNum\": %d}", seqNum);
                state = SEND_REQUEST;
                break;
            }
            case FOUND_GREEN:{
                sprintf(body, "{\"color\": \"green\", \"xcor\": 1, \"ycor\": 3, \"seqNum\": %d}", seqNum);
                state = SEND_REQUEST; 
                break;
            }
            case FOUND_NONE:{
                sprintf(body, "{\"color\": \"none\", \"xcor\": 0, \"ycor\": 0, \"seqNum\": %d}", seqNum);
                state = SEND_REQUEST;
                break;
            }
            case SEND_REQUEST:{
                sent_msg_size = strlen(body);
                strcpy(msg.request, "PUT /PixyCam_State HTTP/1.1\r\nHost: 192.168.20.57\r\nContent-Type: application/json\r\n");           
                sprintf(buff, "Content-Length: %d\r\n\r\n%s\r\n\r\n", sent_msg_size, body);
                strcat(msg.request, buff);
                seqNum += 1;
                sendWiFlyThreadQueue(msg);
                state = START;
            }
        }
    }
    //dbgOutputLoc(LEAVE_FIND_BLOCK);
}




