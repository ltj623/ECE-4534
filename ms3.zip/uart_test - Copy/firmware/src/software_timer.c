#include "software_timer.h"



void sendToUART(TimerHandle_t xTimer){
    //dbgOutputLoc(ENTER_TIMER);
    PLIB_PORTS_PinToggle(PORTS_ID_0, PORT_CHANNEL_A, PORTS_BIT_POS_3);
    BaseType_t good;
    static uint16_t count = 0;
    switch(count){
        case(0):{
            good = sendPixyValueToQueue(0xae);
            count = count + 1;
            break;
        }
        case(1):{
            good = sendPixyValueToQueue(0xc1);
            count = count + 1;
            break;
        }
        case(2):{
            good = sendPixyValueToQueue(0x20);
            count += 1;
            break;
        }
        case(3):{
            good = sendPixyValueToQueue(0x02);
            count += 1;
            break;
        }
        case(4):{
            good = sendPixyValueToQueue(0xff);
            count += 1;
            break;
        }
        case(5):{
            good = sendPixyValueToQueue(0xfe);
            count = 0;
            break;
        } 
    }
    //dbgOutputLoc(LEAVE_TIMER);
    SYS_INT_SourceEnable(INT_SOURCE_USART_1_TRANSMIT);
    SYS_INT_SourceEnable(INT_SOURCE_USART_1_RECEIVE); 
}

BaseType_t isTimerActive(){
    if( xTimerIsTimerActive( timerHndl100ms ) != pdFALSE )
    {
        return pdTRUE;
    }
    else
    {
        return pdFALSE;
    }
}
void create100msTimer(){
 timerHndl100ms = xTimerCreate
                 ( "timer100ms",
                   pdMS_TO_TICKS(250),
                   pdTRUE,
                  (void*) 0,
                  sendToUART);
}

void start100msTimer(){
     xTimerStart( timerHndl100ms, 0 );  
}

void stop100msTimer(){
     xTimerStop( timerHndl100ms, 0 );
}

void reset100msTimer(){
    xTimerReset(timerHndl100ms, 250 );
}