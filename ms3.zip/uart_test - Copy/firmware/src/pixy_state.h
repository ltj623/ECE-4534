#ifndef _PIXY_STATE_H    /* Guard against multiple inclusion */
#define _PIXY_STATE_H


#ifdef __cplusplus
extern "C" {
#endif

#include "debug.h"
#include "pixy_thread.h"
#include <queue.h>
#include "pixy_queue.h"
   
struct PixyData {
      uint16_t block_code;
      uint16_t x_pos;
      uint16_t y_pos;
  };

void find_block(char data);
    

#ifdef __cplusplus
}
#endif

#endif 