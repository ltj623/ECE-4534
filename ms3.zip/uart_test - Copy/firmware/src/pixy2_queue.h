#ifndef _PIXY_QUEUE_H    /* Guard against multiple inclusion */
#define _PIXY_QUEUE_H

#include "FreeRTOS.h"
#include <queue.h>
#include "debug.h"
#include "pixy_thread.h"

#ifdef __cplusplus
extern "C" {
#endif


QueueHandle_t UART1Queue;
QueueHandle_t PixyThreadQueue;
void createPixyQueue();
BaseType_t sendPixyThreadQueueISR(char msg);
BaseType_t sendPixyThreadQueue(char msg);
BaseType_t sendUART1Queue(char msg);
char receivePixyThreadQueue();
void receiveUART1QueueISR(char * msg);
BaseType_t PixyThreadQueueEmpty();
BaseType_t UART1QueueEmpty();
UBaseType_t spaceInPixyThreadQueue();
    
#ifdef __cplusplus
}
#endif

#endif 


