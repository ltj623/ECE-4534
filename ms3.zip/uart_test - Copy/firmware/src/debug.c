#include "debug.h"

void dbgOutputLoc(unsigned int outVal){
    PLIB_PORTS_Write(PORTS_ID_0, PORT_CHANNEL_E, outVal);
}

 void ERROR_CHECK(bool errorFree){
    if(!errorFree){
        //STOP ISR
        //STOP ALL OTHER TASKS
        vTaskSuspendAll();  
        while( true ) {
            dbgOutputLoc(ERROR);
        }
    } 
}