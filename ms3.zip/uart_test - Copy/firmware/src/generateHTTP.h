#ifndef _GENERATEHTTP_H
#define _GENERATEHTTP_H

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include "FreeRTOS.h"
#include "debug.h"
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include "system_config.h"
#include "system_definitions.h"
#include "pixy_state.h"


// DOM-IGNORE-BEGIN
#ifdef __cplusplus  // Provide C++ Compatibility

extern "C" {

#endif
// DOM-IGNORE-END 
  
 typedef enum {
    START,
    FOUND_RED,
    FOUND_GREEN,
    FOUND_NONE,
    SEND_REQUEST,
    WAIT,
  } PIXY_STATE;
  
  
void GENERATEHTTP_Initialize ( void );
void GENERATEHTTP_Tasks( void );


#endif /* _GENERATEHTTP_H */

//DOM-IGNORE-BEGIN
#ifdef __cplusplus
}
#endif
//DOM-IGNORE-END

/*******************************************************************************
 End of File
 */

